<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: DELETE");
header("Access-Control-Allow-Headers:Content-Type,Access-Control-Allow-Headers,Authorization,X-Requested-With");

$conn=mysqli_connect('localhost','root','','meal_manager');


  @$id = $_REQUEST['id'];

  $sql="DELETE FROM `meal_manager`.`member` WHERE `id` = '$id'";

  if ($conn->query($sql) === TRUE) {
    echo "Record Deleted";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

$conn->close();


 ?>