<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POS");
header("Access-Control-Allow-Headers:Content-Type,Access-Control-Allow-Headers,Authorization,X-Requested-With"); 


$conn=mysqli_connect('localhost','root','','meal_manager');


@$name= $_REQUEST['name'];

$query = "SELECT `name`,`no_meal`,`date` FROM `manage_meal` WHERE `name`='$name' ORDER BY DATE ASC";

$result = $conn->query($query);


$emparray = array();
    while($row =mysqli_fetch_assoc($result))
    {
        $emparray[] = $row;
    }

echo json_encode($emparray);

$conn->close();


?>

