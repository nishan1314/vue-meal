<?php 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With"); 

class invenback
{

private $conn;
	public function __construct(){
		$db_host = 'localhost';
		$db_user = 'root';
		$db_pass = '';
		$db_name = 'meal_manager';

		$this->conn = mysqli_connect($db_host,$db_user,$db_pass,$db_name);


		if(!$this->conn){
			die("Database Connection Failed");
		}
		else{
			// echo "Database connected Successfully";
		}
	}




	public function add_member(){
		@$id = $_REQUEST['id'];
		@$mem_name = $_REQUEST['name'];
		@$contact = $_REQUEST['contact'];
		$query = "INSERT INTO member VALUES('$id','$mem_name','$contact')";

		if(mysqli_query($this->conn,$query)){
					return "Added Successfull!";
				}

	}

	public function show_mem(){
		$query = "SELECT * FROM member";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}

	public function deposite(){

		@$id = $_REQUEST['id'];
		@$mem_name = $_REQUEST['name'];
		@$amount = $_REQUEST['amount'];
		@$date = $_REQUEST['date'];

		$query = "INSERT INTO deposite VALUES('$id','$mem_name','$amount','$date')";

		if(mysqli_query($this->conn,$query)){
			return "Added Successfull!";
		 }

	}

	public function show_dep(){
		$query = "SELECT * FROM deposite ORDER BY DATE ASC";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}

	public function total_dep(){
		$query = "SELECT * FROM total_dep";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}


	public function add_expenses(){
		@$id = $_REQUEST['id'];
		@$ex_amount = $_REQUEST['amount'];
		@$date= $_REQUEST['date'];

		$query = "INSERT INTO expenses VALUES('$id','$ex_amount','$date')";

		if(mysqli_query($this->conn,$query)){
					return "Added Successfull!";
				}

	}


	public function show_expen(){
		$query = "SELECT * FROM expenses_his ORDER BY DATE ASC";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}

	public function total_expen(){
		$query = "SELECT * FROM total_expen";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}


	public function add_meal(){

		@$id = $_REQUEST['id'];
		@$mem_name = $_REQUEST['name'];
		@$no_meal = $_REQUEST['no_meal'];
		@$date = $_REQUEST['date'];

		$query = "INSERT INTO manage_meal VALUES('$id','$mem_name','$no_meal','$date')";

		if(mysqli_query($this->conn,$query)){
			return "Added Successfull!";
		 }

	}



	public function show_meal(){
		$query = "SELECT * FROM member_tmeal";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}



	public function total_meal(){
		$query = "SELECT * FROM total_meal";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}


		public function meal_dash(){
		$query = "SELECT * FROM meal_dash";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}


		public function final_report(){
		$query = "SELECT * FROM final_report";

		if(mysqli_query($this->conn,$query)){
			$return_data = mysqli_query($this->conn,$query);
			return $return_data;
		}

	}


	public function trunc_deposite(){

		$query = "TRUNCATE deposite";

		if(mysqli_query($this->conn,$query)){
			return "Table Cleared";
		 }

	}


	public function trunc_expen(){

		$query = "TRUNCATE expenses";

		if(mysqli_query($this->conn,$query)){
			return "Table Cleared";
		 }

	}

	public function trunc_meal(){

		$query = "TRUNCATE manage_meal";

		if(mysqli_query($this->conn,$query)){
			return "Table Cleared";
		 }

	}











}



?>